#ifndef _CHAR_LIBRARY_H
#define _CHAR_LIBRARY_H



#include "stm32f10x.h"
#include <stdio.h>
#include <stdlib.h>

/*�����ַ�*/
extern uint8_t kai[],kun[],zhi[],liu[],dian[],ji[],deng[],ji4[],
				qi[],guan[],bu[],jin[],cai[],bian[],se[],gantanhao[],wen[],du[],shi[];

/*�ַ���*/
extern uint8_t zfk[];
extern uint8_t hz_shuzi[];

/*ASCII��*/
extern uint8_t ASCII_8_16[];

/*ȫ�ֱ���*/
extern uint32_t shuzi_cnt;
extern uint32_t zfk_cnt;


#endif /*_Char_Library.h*/


