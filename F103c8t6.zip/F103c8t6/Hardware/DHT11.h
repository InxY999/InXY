#ifndef _DHT11_H
#define _DHT11_H


#include "stm32f10x.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include	"Tim4.h"

typedef struct
{
	uint8_t Hum_H;
	uint8_t Hum_L;
	uint8_t Tem_H;
	uint8_t Tem_L;
	uint8_t Check;
	float 	Humi;
	float 	Temp;
	
}DHT11_t;
extern DHT11_t DHT11;
extern uint8_t Buf_Tem[10],Buf_Hum[10];


#define DHT11_Clock			RCC_APB2Periph_GPIOB
#define DHT11_PORT      GPIOB
#define DHT11_PIN				GPIO_Pin_3
#define DHT11_SET_H()		GPIO_SetBits(DHT11_PORT,DHT11_PIN);
#define DHT11_SET_L()		GPIO_ResetBits(DHT11_PORT,DHT11_PIN);

#define DHT11_DATA     (GPIO_ReadInputDataBit(DHT11_PORT,DHT11_PIN))

void DHT11_Config(void);
void DHT11_Start(void);
//uint8_t DHT11_Response(void);
uint8_t DHT11_ReadBit(void);
uint8_t DHT11_ReadByte(void);
uint8_t DHT11_Check(void);
uint8_t DHT11_GetVal(void);


uint8_t DHT11_RecvByte(void);

#endif /*DHT11.h*/

