#ifndef _DELAY_H
#define _DELAY_H


#include "stm32f10x.h"


void Delay_Func(void);



#endif /*Dealy.h*/
