#include "ESP8266.h"


//		if(!Key_flag)
//		{
//			Key = Key_scan();
//			if((Key == 1) && (Wifi_Flag==0))
//			{
//				gizwitsSetMode(WIFI_RESET_MODE);
//				printf("Wifi Reset\r\n");
//				Wifi_Flag =1;
//			}
//			if((Key == 2) && (Wifi_Flag ==1))
//			{
//				gizwitsSetMode(WIFI_AIRLINK_MODE);
//				printf("Wifi Connect\r\n");
//				Wifi_Complete = 1;
//				Key_flag = 1;
//			}
//		}
//		
//		if(Wifi_Complete)
//		{
//			DHT11_GetVal();
//			userHandle();//��ʱ�����ݸ���
//			gizwitsHandle((dataPoint_t *)&currentDataPoint);
//		}

