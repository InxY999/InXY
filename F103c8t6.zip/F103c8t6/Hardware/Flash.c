#include "Flash.h"


	/*�����ڴ洢��Ϣ*/
///*
//#define Flash_Write_Start_Addr   ((uint32_t)0x0800C800) 
//#define Flash_Write_End_Addr     ((uint32_t)0x0800EFFF)
//#define FLASH_PAGE_SIZE   			 ((uint16_t)0x400)
//	
//uint32_t Address = 0x00;
//uint8_t Phone_Num[11] = "15137574498";
//uint8_t Name[6] = "������"; //������������ռ2�ֽ�

//uint32_t Flash_cnt=0;
//volatile FLASH_Status FLASHStatus = FLASH_COMPLETE;
//volatile uint8_t Flash_Check_Flag = 1;

//FLASH_Unlock();//����flash
//	FLASH_ClearFlag(FLASH_FLAG_EOP | FLASH_FLAG_PGERR | FLASH_FLAG_WRPRTERR);	
//	
//	/*����50��51ҳFlash*/
//	//����Flash_ErasePage����Ϊĳҳ����һ��ַ���ɲ�����ҳ
//	FLASH_ErasePage(Flash_Write_Start_Addr + FLASH_PAGE_SIZE * 0);
//	FLASH_ErasePage(Flash_Write_Start_Addr + FLASH_PAGE_SIZE * 1);
//	Address = Flash_Write_Start_Addr;

//	/*��50ҳ��绰��*/
//	while((Address<Flash_Write_Start_Addr + FLASH_PAGE_SIZE * 1 - 1))
//	{
//			FLASHStatus = FLASH_ProgramWord(Address,Phone_Num[Flash_cnt]);  //��������洢��MemoryProgramStatus������
//			Address += 4;
//			Flash_cnt++;
//			if(Flash_cnt == (sizeof(Phone_Num)/sizeof(Phone_Num[0])))
//			{
//				Flash_cnt = 0;
//				break;
//			}
//	}
//	/*��51ҳ������*/
//	Address = Flash_Write_Start_Addr + FLASH_PAGE_SIZE * 1;
//	while((Address<Flash_Write_Start_Addr + FLASH_PAGE_SIZE * 2 - 1))
//	{
//			FLASHStatus = FLASH_ProgramWord(Address,Name[Flash_cnt]);  //��������洢��MemoryProgramStatus������
//			Address += 4;
//			Flash_cnt++;
//			if(Flash_cnt == (sizeof(Name)/sizeof(Name[0])))break;
//	}
//	FLASH_LockBank1();//��Flash
///*
//	//���д��������ȷ��
////	Address = Flash_Write_Start_Addr;
////	while((Address < Flash_Write_Start_Addr + FLASH_PAGE_SIZE * 1) && (Flash_Check_Flag !=0))
////	{
////		if(*(uint32_t*)Address != Phone_Num[Flash_cnt])
////		{
////			Flash_Check_Flag = 0;
////		}
////		Address+=4;
////	}
////	while((Address < Flash_Write_Start_Addr + FLASH_PAGE_SIZE * 2) && (Flash_Check_Flag !=0))
////	{
////		if(*(uint32_t*)Address != Phone_Num[Flash_cnt])
////		{
////			Flash_Check_Flag = 0;
////		}
////		Address+=4;
////	}
////	
////	Flash_cnt = 0;
////	while((Address < Flash_Write_Start_Addr + FLASH_PAGE_SIZE * 3) && (Flash_Check_Flag !=0))
////	{
////		if(*(uint32_t*)Address != Name[Flash_cnt])
////		{
////			Flash_Check_Flag = 0;
////		}
////		Address+=4;
////		Flash_cnt++;
////	}
//			
//			
//			
//		Address = Flash_Write_Start_Addr;
//		printf("Phone Num : ");
//		for(uint8_t i=0;i<11;i++)
//		{
//			printf("%c",*(uint32_t*)(Address + 4 * i));
//		}
//		Address = Flash_Write_Start_Addr;
//		printf("\r\nName : ");
//		for(uint8_t i=0;i<7;i++)
//		{	
//		printf("%c",*(uint32_t*)(Address + FLASH_PAGE_SIZE * 1 + 4 * i));
//		}
//*/

