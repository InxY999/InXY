#include "IrDA.h"


/*�������벶������->������*/

void TIM2_PA1_Config(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);//GPIOA RCCʹ��
	/*****PA1*****/
	GPIO_InitTypeDef GPIO_InitStruct;
	GPIO_InitStruct.GPIO_Pin	= GPIO_Pin_1;    // �˿ںţ�1
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN_FLOATING; //�˿�ģʽ����������
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStruct); //����ת��(���룡)
//	GPIO_PinRemapConfig(GPIO_PartialRemap2_TIM2,ENABLE);

/*Tim2 CH2  ->PA1*/
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2,ENABLE);//TIM2 RCCʹ��
	/*TIM2 ʱ������ ->10ms*/
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct;
	TIM_TimeBaseInitStruct.TIM_Period = 10000 - 1;//���ʱ��
  TIM_TimeBaseInitStruct.TIM_Prescaler = 72 - 1;
  TIM_TimeBaseInitStruct.TIM_ClockDivision = TIM_CKD_DIV1;
  TIM_TimeBaseInitStruct.TIM_CounterMode = TIM_CounterMode_Up;
  TIM_TimeBaseInitStruct.TIM_RepetitionCounter = 0x0000;
	TIM_TimeBaseInit(TIM2, &TIM_TimeBaseInitStruct);
	/*���벶�� ->CH2 */
	TIM_ICInitTypeDef TIM_ICInitStruct;
	TIM_ICInitStruct.TIM_Channel = TIM_Channel_2;
  TIM_ICInitStruct.TIM_ICPolarity = TIM_ICPolarity_Rising;
  TIM_ICInitStruct.TIM_ICSelection = TIM_ICSelection_DirectTI;
  TIM_ICInitStruct.TIM_ICPrescaler = TIM_ICPSC_DIV1;
  TIM_ICInitStruct.TIM_ICFilter = 0x00;
	TIM_ICInit(TIM2, &TIM_ICInitStruct);
	/*�ж�����*/
	TIM_ITConfig(TIM2,TIM_IT_Update,ENABLE);
	TIM_ITConfig(TIM2,TIM_IT_CC2,ENABLE);
	TIM_ClearFlag(TIM2,TIM_IT_Update);//���־λ
	TIM_ClearFlag(TIM2,TIM_IT_CC2);//���־λ
	NVIC_SetPriority(TIM2_IRQn,NVIC_EncodePriority(7-2,1,1));
	NVIC_EnableIRQ(TIM2_IRQn);

	TIM_Cmd(TIM2, ENABLE);//ʹ�ܼ�ʱ��
}

IrDA_Data_t IrDA_Data;
uint8_t Each_8_Blank = 0;
uint8_t IrDA_Save[32];
void TIM2_IRQHandler(void)
{
	if(TIM_GetFlagStatus(TIM2,TIM_IT_CC2))
	{
		TIM_ClearITPendingBit(TIM2,TIM_IT_CC2);
		if(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1))//�ߵ�ƽ�ж�
		{
			TIM_SetCounter(TIM2,0);//�������㣬�������
			TIM_OC2PolarityConfig(TIM2,TIM_ICPolarity_Falling);//��Ϊ�½���
		}
		else		//�����ж�ʱΪ�͵�ƽ�����½��ؽ����ж�
		{
			TIM_OC2PolarityConfig(TIM2,TIM_ICPolarity_Rising);//��Ϊ������
			IrDA_Data.CCR2_Value = TIM_GetCapture2(TIM2);
			if(IrDA_Data.Start_Flag == 0)//δ���յ�������ʱ
			{
				if(IrDA_Data.CCR2_Value >=4200 && IrDA_Data.CCR2_Value <=4800)//�������ź�ʱ���ж�
				{
					IrDA_Data.Start_Flag = 1;//�������־λ��1
				}
			}
			else if (IrDA_Data.Start_Flag == 1) //���յ��������
			{
				if(!(Each_8_Blank % 4))
				{
					printf(" ");
				}
	
				if(IrDA_Data.CCR2_Value >= 300 && IrDA_Data.CCR2_Value <= 800)
				{	//�͵�ƽ->0.56ms�ߵ�ƽ+0.56ms�͵�ƽ
					IrDA_Data.Code_Value = IrDA_Data.Code_Value >>1;
					IrDA_Data.Code_Value |= 0x00000000;
					printf("0"); 		
					IrDA_Save[Each_8_Blank] = '0';
					Each_8_Blank++;
				}
				else if(IrDA_Data.CCR2_Value >=1400 && IrDA_Data.CCR2_Value<=1800)
				{	//�ߵ�ƽ->0.56ms�ߵ�ƽ+1.96ms�͵�ƽ
					IrDA_Data.Code_Value = IrDA_Data.Code_Value >>1;
					IrDA_Data.Code_Value |= 0x80000000;
					printf("1");		
					IrDA_Save[Each_8_Blank] = '1';
					Each_8_Blank++;
				}
//					if(Each_8_Blank == 32)
//					{
//						Each_8_Blank = 0;
//						for(uint8_t i=0;i<32;i++)
//						{
//							printf("IrDA_Save[i] = %d",IrDA_Save[i]);
//						}
//					}
			}
		}	
	}
	
	/*�������*/
	if(TIM_GetITStatus(TIM2,TIM_IT_Update))//�ж����->���ݴ������
	{
		TIM_ClearITPendingBit(TIM2,TIM_IT_Update);//�����־λ
		if(IrDA_Data.Start_Flag)
		{
				IrDA_Data.Over_Flag = 1;//������ɱ�־λ
				IrDA_Data.Start_Flag = 0;
		}
	}
}

uint8_t IrDA_Analysis_Data(void)
{
	if(IrDA_Data.Over_Flag)
	{
		IrDA_Data.Addr_Ycode = (IrDA_Data.Code_Value & 0x000000FF) >> 0;//���Ƚ��յ���ֵ�������λ
		IrDA_Data.Addr_Fcode = (IrDA_Data.Code_Value & 0x0000FF00) >> 8;//�ν��յ�ֵ����ε�λ
		IrDA_Data.Data_Ycode = (IrDA_Data.Code_Value & 0x00FF0000) >> 16;
		IrDA_Data.Data_Fcode = (IrDA_Data.Code_Value & 0xFF000000) >> 24;
		IrDA_Data.Over_Flag = 0;
		/*ԭ����У��*/
		if(IrDA_Data.Addr_Ycode == (uint8_t)(~IrDA_Data.Addr_Fcode))
		{
			if(IrDA_Data.Data_Ycode == (uint8_t)(~IrDA_Data.Data_Fcode))
			{
				printf("\r\nIrDA_Data.Data_Ycode = %d \r\n",IrDA_Data.Data_Ycode);
			 	return IrDA_Data.Data_Ycode;
			}
		}
		else
		{
				printf("\r\nIrDA_Data.Data_Ycode = %d \r\n",0xFF);
				return 0xFF;
		}
	}
	return 0xFF;
}


//static uint32_t IrDA_Command = 0,Led_Command = 0,Relay_Command = 0,
//			Step_Motor_Command = 0,Motor_Command = 0;	

//IrDA_Command = IrDA_Analysis_Data();
//		switch(IrDA_Command)
//			{
//				case 69://1
//				{
//					OLED_Clear();
//					OLED_Show16_16HanZi(0,0,deng);
//					Led_Command ^=1;
//					if(Led_Command)
//					{				
//						OLED_Show16_16HanZi(112,3,kai);
//						OLED_ShowPicture(32,0,64,64,gImage_LED);
//					//	LED_ON();
//					}
//					else if(!Led_Command)
//					{
//						OLED_Show16_16HanZi(112,3,guan);
//					//	LED_OFF();
//					}
//				} break;
//				case 70://2
//				{
//					OLED_Clear();
//					Motor_Command ^=1;
//					OLED_Show16_16HanZi(0,0,zhi);
//					OLED_Show16_16HanZi(0,2,liu);
//					OLED_Show16_16HanZi(0,4,dian);
//					OLED_Show16_16HanZi(0,6,ji);
//					
//					if(Motor_Command)
//					{
//						OLED_Show16_16HanZi(112,3,kai);
//						OLED_ShowPicture(32,0,64,64,gImage_Motor);
//					//  Motor_Foreward();
//					}
//					else if(!Motor_Command)
//					{
//							OLED_Show16_16HanZi(112,3,guan);
//					//	Motor_Stop();
//					}
//				}break;
//				case 71://3
//				{
//					OLED_Clear();
//					Step_Motor_Command ^=1;
//					OLED_Show16_16HanZi(0,0,bu);
//					OLED_Show16_16HanZi(0,2,jin);
//					OLED_Show16_16HanZi(0,4,dian);
//					OLED_Show16_16HanZi(0,6,ji);
//					if(Step_Motor_Command)
//					{
//						OLED_Show16_16HanZi(112,3,kai);
//						OLED_ShowPicture(32,0,64,64,gImage_Motor);
//					//	Step_Motor_Ctrl2(100,2);
//					}
//					else if(!Step_Motor_Command)
//					{
//						OLED_Show16_16HanZi(112,3,guan);
//					//	Step_Motor_Ctrl2(0,1);
//					}
//				}break;
//				case 68:
//				{
//					OLED_Clear();
//					Relay_Command ^=1;
//					OLED_Show16_16HanZi(0,0,ji4);
//					OLED_Show16_16HanZi(0,2,dian);
//					OLED_Show16_16HanZi(0,4,qi);
//					if(Relay_Command)
//					{
//						OLED_Show16_16HanZi(112,3,kai);
//						OLED_ShowPicture(32,0,64,64,gImage_relay);
//					//	Relay_Func(ENABLE);
//					}
//					else if(!Relay_Command)
//					{
//						OLED_Show16_16HanZi(112,3,guan);
//					//	Relay_Func(DISABLE);
//					}
//				}break;
//				case 64:
//				{
//					OLED_Clear();
//					OLED_Show16_16HanZi(0,0,cai);
//					OLED_Show16_16HanZi(0,4,deng);
//					OLED_ShowPicture(32,0,64,64,gImage_rgb);
//					/*PB10->������3ģʽ��Ϊ��©����ʵ�֣�ģ���ƽ�����������룬����������ɫֵ*/
//					GPIO_SetBits(GPIOB,GPIO_Pin_10);			
//					GPIO_ResetBits(GPIOB,GPIO_Pin_10);
//					GPIO_SetBits(GPIOB,GPIO_Pin_10);
//					RGB_Config(TIM_Gener[0],TIM_Gener[1],TIM_Gener[2]);
//					OLED_Show16_16HanZi(112,0,bian);
//					OLED_Show16_16HanZi(112,2,se);
//					OLED_Show16_16HanZi(112,4,gantanhao);
//					OLED_Show16_16HanZi(112,6,gantanhao);
//				}
//		}

