#ifndef _LED_H
#define _LED_H


#include "stm32f10x.h"

#include "Delay.h"

void LED_Config(void); //Led���ú���



void LED_ON(void);
void LED_OFF(void);
void LED1_Toggle(void);

#endif /*Led.h*/

