#ifndef _MOTOR_H
#define _MOTOR_H


#include "stm32f10x.h"


void Motor_Config(void);
void Motor_Foreward(void);
void Motor_Reversal(void);
void Motor_Stop(void);

void Motor_Func(uint8_t Dir);

#endif /*Motor.h*/
