#ifndef _RGB_H
#define _RGB_H


#include "stm32f10x.h"
#include <stdio.h>
#include "Sys.h"


void RGB_GPIO_Config(void);

uint32_t RGB_Group_Pack(uint8_t R,uint8_t G,uint8_t B);
void RGB_Send_Data(uint32_t data);
void RGB_Config(uint8_t R,uint8_t G,uint8_t B);
uint32_t RGB_Color_Data2(uint32_t Color);


#endif /*RGB.h*/
