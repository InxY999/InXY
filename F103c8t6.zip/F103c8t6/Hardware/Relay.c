#include "Relay.h"


void Relay_Config(void)
{
	GPIO_InitTypeDef GPIO_InitStruct;
		/*Relay ->PB1*/
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);//GPIOB RCCʹ��
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStruct.GPIO_Pin	= GPIO_Pin_1;    // �˿ںţ�1
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP; //�˿�ģʽ���������
	GPIO_Init(GPIOB,&GPIO_InitStruct); //����ת��(���룡)
}

void Relay_Func(uint8_t NewState)
{
	 if (NewState != DISABLE)
  {
    GPIO_SetBits(GPIOB,GPIO_Pin_1);
  }
  else
  {
    GPIO_ResetBits(GPIOB,GPIO_Pin_1);
  }
	
}

