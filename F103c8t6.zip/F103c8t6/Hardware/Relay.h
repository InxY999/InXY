#ifndef _RELAY_H
#define _RELAY_H


#include "stm32f10x.h"



void Relay_Config(void);
void Relay_Func(uint8_t NewState);
	
	
	
#endif /*Relay.h*/

