#ifndef _REMOTE_H
#define _REMOTE_H


#include "stm32f10x.h"
#include "Sys.h"
#include "IrDA.h"



#endif /*Remote.h*/


