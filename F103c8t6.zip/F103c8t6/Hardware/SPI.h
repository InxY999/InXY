#ifndef _SPI_H
#define _SPI_H


#include "stm32f10x.h"
#include <stdio.h>





#endif /*SPI.h*/
