#ifndef _STEP_MOTOR_H
#define _STEP_MOTOR_H


#include "stm32f10x.h"
#include "Tim4.h"


/*
PA4 ->!B ->B_
PA5 ->B  ->B
PA6 ->!A ->A_
PA7 ->A  ->A
*/

#define AStart 			GPIO_SetBits(GPIOA,GPIO_Pin_7);
#define AStop 			GPIO_ResetBits(GPIOA,GPIO_Pin_7);
#define BStart 			GPIO_SetBits(GPIOA,GPIO_Pin_5);
#define BStop				GPIO_ResetBits(GPIOA,GPIO_Pin_5);

#define A_Start 		GPIO_SetBits(GPIOA,GPIO_Pin_6);
#define A_Stop 			GPIO_ResetBits(GPIOA,GPIO_Pin_6);
#define B_Start 		GPIO_SetBits(GPIOA,GPIO_Pin_4);
#define B_Stop 			GPIO_ResetBits(GPIOA,GPIO_Pin_4);

				

void Step_Motor_Config(void);
void Beat_Switch(uint8_t Dir,uint8_t Step_Motor_Cnt);

//void Step_Motor_Ctrl1(int Cnt);
void Step_Motor_Ctrl(uint8_t Dir,uint32_t Step,uint32_t Speed);


#endif /*Step Motor.h*/

