#include "Tim1.h"

#include "gizwits_product.h"
#include "gizwits_protocol.h"

void TIM1_Config(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1,ENABLE);//��TIM4ʱ��
	
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct={0};
	TIM_TimeBaseInitStruct.TIM_CounterMode = TIM_CounterMode_Up;//���ϼ���
	TIM_TimeBaseInitStruct.TIM_Period    = 1000 - 1;
	TIM_TimeBaseInitStruct.TIM_Prescaler = 72 - 1;//72Mhz  T=1/f = 1000hz
	TIM_TimeBaseInit(TIM1,&TIM_TimeBaseInitStruct);
	
	TIM_ITConfig(TIM1,TIM_IT_Update,ENABLE);
	
	NVIC_InitTypeDef NVIC_InitStruct={0};
	NVIC_InitStruct.NVIC_IRQChannel = TIM1_UP_IRQn;//�ж�Դ
	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;//ʹ���ж�Դ
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 2;//��ռ���ȼ�
	NVIC_InitStruct.NVIC_IRQChannelSubPriority = 2;//�μ����ȼ�
	NVIC_Init(&NVIC_InitStruct);
	
	TIM_Cmd(TIM1,ENABLE);
}


void TIM1_UP_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM1,TIM_IT_Update) != RESET)
	{
		TIM_ClearITPendingBit(TIM1,TIM_IT_Update);	
		gizTimerMs();
	}
}

