#ifndef _TIM1_H
#define _TIM1_H


#include "stm32f10x.h"
#include <stdio.h>



void TIM1_Config(void);


#endif /*Tim1.h*/


