#ifndef _TIM3_H
#define _TIM3_H


#include "stm32f10x.h"
#include "Sys.h"


void TIM3_PB5_Config(void);
void TIM3_CH2_PWM_Config(void);
void TIM3_CH2_Config(uint32_t rec_num);

extern uint8_t RGB_Command;


#endif /*Tim4.h*/


