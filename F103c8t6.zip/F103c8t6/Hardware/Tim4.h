#ifndef _TIM4_H
#define _TIM4_H


#include "stm32f10x.h"
#include "Sys.h"

#include "Led.h"

/*PB8 ->CH3*/
void TIM4_CH3_Init(void);
void TIM4_PB8_Config(void);
void TIM4_CH3_PWM_Config(void);

void TIM4_CH3_Config(uint32_t rec_num);
void TIM4_Delay_nus(uint16_t nus);
void TIM4_Delay_nms(uint16_t nms);

extern uint8_t Step_Motor_Cnt,RGB_Command;;

#endif /*Tim4.h*/


