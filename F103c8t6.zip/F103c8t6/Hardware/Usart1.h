#ifndef _USART1_H
#define _USART1_H


#include "stm32f10x.h"
#include <stdio.h>

typedef struct 
{
	uint8_t recvbuff[100];
	uint8_t recvcnt;
	uint8_t recvflag;
	
}Usart1_recv_t;

extern Usart1_recv_t Usart1_recv;

void Usart1_IT_Config(void);
void Usart1_GPIO_Config(void);
void Usart1_Config(uint32_t BaudRate);

void Usart1_sendbyte(uint8_t byte);
void Usart1_sendstr(uint8_t *pstr);
uint8_t Usart1_recbyte(void);


#endif /*Usart1.h*/
