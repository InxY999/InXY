#ifndef _USART2_H
#define _USART2_H


#include "stm32f10x.h"
#include <stdio.h>




#define USART2_GPIO_CLK RCC_APB1Periph_USART2  
#define USART2_PORT     GPIOA
#define USART2_TX_PIN   GPIO_Pin_2
#define USART2_RX_PIN   GPIO_Pin_3


#define RECV_BUFF_SIZE  50

void USART2_Init(uint32_t BaudRate);
void USART2_SendByte(uint8_t Byte);
void USART2_SendString(char* String);


#endif /*Usart2.h*/
