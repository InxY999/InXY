#ifndef _MAIN_H
#define _MAIN_H


#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <math.h>

#include "stm32f10x.h"

#include "Delay.h" 
#include "Led.h"
#include "Key.h"
#include "Exti.h"
#include "Motor.h"
#include "Usart1.h"
#include "Relay.h"
#include "DHT11.h"
#include "Usart2.h"
#include "Sys.h"
#include "Tim4.h"
#include "Tim3.h"
#include "RGB.h"
#include "Step Motor.h"
#include "IrDA.h"
#include "OLED.h"
#include "Tim1.h"




/*ȡģ��*/
#include "Pic func.h"
#include "Char Library.h"


#endif /*main.h*/








