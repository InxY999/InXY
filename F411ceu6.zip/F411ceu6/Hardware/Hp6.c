#include "Hp6.h"

uint8_t tx_buf[24] = {0};//�������ݰ�
uint8_t rx_buf[24] = {0};//�������ݰ�

/*crcУ���*/
const uint16_t crc16_tab[256] =
{
	0x0000, 0xC0C1, 0xC181, 0x0140, 0xC301, 0x03C0, 0x0280, 0xC241,   
	0xC601, 0x06C0, 0x0780, 0xC741, 0x0500, 0xC5C1, 0xC481, 0x0440,   
	0xCC01, 0x0CC0, 0x0D80, 0xCD41, 0x0F00, 0xCFC1, 0xCE81, 0x0E40,   
	0x0A00, 0xCAC1, 0xCB81, 0x0B40, 0xC901, 0x09C0, 0x0880, 0xC841,   
	0xD801, 0x18C0, 0x1980, 0xD941, 0x1B00, 0xDBC1, 0xDA81, 0x1A40,   
	0x1E00, 0xDEC1, 0xDF81, 0x1F40, 0xDD01, 0x1DC0, 0x1C80, 0xDC41,   
	0x1400, 0xD4C1, 0xD581, 0x1540, 0xD701, 0x17C0, 0x1680, 0xD641,   
	0xD201, 0x12C0, 0x1380, 0xD341, 0x1100, 0xD1C1, 0xD081, 0x1040,   
	0xF001, 0x30C0, 0x3180, 0xF141, 0x3300, 0xF3C1, 0xF281, 0x3240,   
	0x3600, 0xF6C1, 0xF781, 0x3740, 0xF501, 0x35C0, 0x3480, 0xF441,   
	0x3C00, 0xFCC1, 0xFD81, 0x3D40, 0xFF01, 0x3FC0, 0x3E80, 0xFE41,   
	0xFA01, 0x3AC0, 0x3B80, 0xFB41, 0x3900, 0xF9C1, 0xF881, 0x3840,   
	0x2800, 0xE8C1, 0xE981, 0x2940, 0xEB01, 0x2BC0, 0x2A80, 0xEA41,   
	0xEE01, 0x2EC0, 0x2F80, 0xEF41, 0x2D00, 0xEDC1, 0xEC81, 0x2C40,   
	0xE401, 0x24C0, 0x2580, 0xE541, 0x2700, 0xE7C1, 0xE681, 0x2640,   
	0x2200, 0xE2C1, 0xE381, 0x2340, 0xE101, 0x21C0, 0x2080, 0xE041,   
	0xA001, 0x60C0, 0x6180, 0xA141, 0x6300, 0xA3C1, 0xA281, 0x6240,  
	0x6600, 0xA6C1, 0xA781, 0x6740, 0xA501, 0x65C0, 0x6480, 0xA441,   
	0x6C00, 0xACC1, 0xAD81, 0x6D40, 0xAF01, 0x6FC0, 0x6E80, 0xAE41,   
	0xAA01, 0x6AC0, 0x6B80, 0xAB41, 0x6900, 0xA9C1, 0xA881, 0x6840,   
	0x7800, 0xB8C1, 0xB981, 0x7940, 0xBB01, 0x7BC0, 0x7A80, 0xBA41,   
	0xBE01, 0x7EC0, 0x7F80, 0xBF41, 0x7D00, 0xBDC1, 0xBC81, 0x7C40,   
	0xB401, 0x74C0, 0x7580, 0xB541, 0x7700, 0xB7C1, 0xB681, 0x7640,   
	0x7200, 0xB2C1, 0xB381, 0x7340, 0xB101, 0x71C0, 0x7080, 0xB041,   
	0x5000, 0x90C1, 0x9181, 0x5140, 0x9301, 0x53C0, 0x5280, 0x9241,   
	0x9601, 0x56C0, 0x5780, 0x9741, 0x5500, 0x95C1, 0x9481, 0x5440,   
	0x9C01, 0x5CC0, 0x5D80, 0x9D41, 0x5F00, 0x9FC1, 0x9E81, 0x5E40,   
	0x5A00, 0x9AC1, 0x9B81, 0x5B40, 0x9901, 0x59C0, 0x5880, 0x9841,   
	0x8801, 0x48C0, 0x4980, 0x8941, 0x4B00, 0x8BC1, 0x8A81, 0x4A40,   
	0x4E00, 0x8EC1, 0x8F81, 0x4F40, 0x8D01, 0x4DC0, 0x4C80, 0x8C41,   
	0x4400, 0x84C1, 0x8581, 0x4540, 0x8701, 0x47C0, 0x4680, 0x8641,   
	0x8201, 0x42C0, 0x4380, 0x8341, 0x4100, 0x81C1, 0x8081, 0x4040 
};

//����Ѫѹ����
const uint8_t bm_open[]=
{0xc8,0xd7,0xb6,0xa5,0x90,0x01,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};


//�ر�Ѫѹ����
const uint8_t bm_close[]=
{0xc8,0xd7,0xb6,0xa5,0x90,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};

//��ȡѪѹ�������
const uint8_t bm_result[]=
{0xc8,0xd7,0xb6,0xa5,0x90,0x02,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};

//�������ʲ���
const uint8_t hb_open[]=
{0xc8,0xd7,0xb6,0xa5,0xD0,0x01,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};

//�ر����ʲ���
const uint8_t hb_close[]=
{0xc8,0xd7,0xb6,0xa5,0xD0,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};

//��ȡ���ʲ������
const uint8_t hb_result[]=
{0xc8,0xd7,0xb6,0xa5,0xD0,0x02,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};


void HP6_I2C_Config(void)
{
	//��ʱ��
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC, ENABLE);
	//�������
	GPIO_InitTypeDef GPIO_InitStruct;
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_2;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStruct);
	//��©���
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_1;
	GPIO_InitStruct.GPIO_OType = GPIO_OType_OD;
	GPIO_Init(GPIOA, &GPIO_InitStruct);
	//ʹ��λ
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_13;
	GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
	GPIO_Init(GPIOC, &GPIO_InitStruct);
	
	GPIO_SetBits(GPIOA, GPIO_Pin_2);
	GPIO_SetBits(GPIOA, GPIO_Pin_1);
	GPIO_ResetBits(GPIOC,GPIO_Pin_13);
	
	delay_ms(50);
}

void HP6_I2C_Start(uint8_t Delay)
{	
	delay_us(Delay);
	HP6_SCL_H;
	HP6_SDA_H;
	delay_us(Delay);
	HP6_SDA_L;
	delay_us(Delay);
	HP6_SCL_L;//����SCL��ȷ��ʱ��ȫ
}

void HP6_I2C_Stop(uint8_t Delay)
{	
	HP6_SDA_L;
	delay_us(Delay);
	HP6_SCL_H;
	delay_us(Delay);
	HP6_SDA_H;
	delay_us(Delay);
}

void HP6_I2C_SendAck(uint8_t Status,uint8_t Delay)
{	
	HP6_SCL_L;
	if(Status)
	{	
		HP6_SDA_H;
	}
	else			
	{	
		HP6_SDA_L;
	}
	delay_us(Delay);
	HP6_SCL_H;
	delay_us(Delay);
	HP6_SCL_L;
}

uint8_t HP6_I2C_RecvAck(uint8_t Delay)
{
	uint8_t ACK = 0;
	HP6_SDA_H;//��©���ͷ�����  �������ٿ���������
	HP6_SCL_L;//����ʱ����
	delay_us(Delay);
	HP6_SCL_H;//����ʱ����
	if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_1))
	{
		ACK = 1;
	}
	delay_us(Delay);
	HP6_SCL_L;
	return ACK;
}

uint8_t HP6_I2C_SendByte(uint8_t Byte,uint8_t Delay)
{
	uint8_t i,ACK;
	for(i = 0; i < 8; i++)
	{
		HP6_SCL_L;
		if(Byte & (0x80>>i))
			HP6_SDA_H;
		else								
			HP6_SDA_L;
		delay_us(Delay);
		HP6_SCL_H;
		delay_us(5);
	}
	HP6_SCL_L;
	ACK = HP6_I2C_RecvAck(Delay);
	return ACK;
}


uint8_t HP6_I2C_RecvByte(uint8_t ACK,uint8_t Delay)
{
	uint8_t Byte = 0 ,i;
	HP6_SDA_H;//�����ͷ����ߣ��ӻ���������
	for(i = 0; i < 8; i++)
	{
		HP6_SCL_L;
		delay_us(Delay);
		HP6_SCL_H;
		Byte <<=1;
		if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_1))
		{
			Byte |= 1;
		}
		delay_us(Delay);
	}
	HP6_SCL_H;
	HP6_I2C_SendAck(ACK,Delay);
	return Byte;
}

uint16_t Crc16(uint8_t *data,uint16_t len)
{
	uint16_t crc16 = 0xFFFF;
	uint32_t uIndex ; 
	while (len--)
	{
		uIndex = (crc16&0xff) ^ ((*data) & 0xff) ; 
		data = data + 1;
		crc16 = ((crc16>>8) & 0xff) ^ crc16_tab[uIndex];
	}
	return crc16 ;
}

void Hp6_Start(uint8_t *pData)
{
	uint8_t i;

	HP6_I2C_Start(5);
	HP6_I2C_SendByte(HP6_WRITE_ADDRESS,10);//д����
	for(i = 0; i < 24; i++)
	{
		HP6_I2C_SendByte(*(pData+i),10);
	}
	HP6_I2C_Stop(5);
}

void Hp6_Recv_Data(uint8_t *pData)
{
	uint8_t i;
	HP6_I2C_Start(5);
	HP6_I2C_SendByte(HP6_READ_ADDRESS,10);//������
	for(i = 0; i < 23; i++)//ǰ23λ
	{
		*(pData+i) = HP6_I2C_RecvByte(0,10);
	}
	*(pData+23) = HP6_I2C_RecvByte(1,10);//��24λ���ӦNAck
	HP6_I2C_Stop(5);
}

uint8_t Hp6_Send_CMD(uint8_t* tx_buf,uint8_t* rx_buf)
{
	uint16_t Crc;
	uint16_t Check_Sum =0;
	Crc=Crc16(&tx_buf[4],18);
	tx_buf[22] = (uint8_t)((Crc&0x00FF)>>0);
	tx_buf[23] = (uint8_t)((Crc&0xFF00)>>8);
	Hp6_Start(tx_buf);
	delay_ms(5);
	Hp6_Recv_Data(rx_buf);
	Crc = *(uint16_t *)(&rx_buf[22]);
	Check_Sum = Crc16(&rx_buf[4],18);
	if(Crc == Check_Sum)
	{
		return 1;
	}
	return 0;
}

//����Ѫѹ����
uint8_t BloodPre_Open(void)
{
	uint8_t i;
	for(i = 0; i < 24; i++)
	{
		rx_buf[i] = 0;
		tx_buf[i] = 0;
	}
	for(i = 0; i < 24; i++)
	{
		tx_buf[i] = bm_open[i];
	}
	return Hp6_Send_CMD(tx_buf,rx_buf);
}


//��ȡ�������
uint8_t Get_BloodPre_Result(void)
{
	uint8_t i;
	for(i = 0; i < 24; i++)
	{
		rx_buf[i] = 0;
		tx_buf[i] = 0;
	}
	for(i = 0; i < 24; i++)
	{
		tx_buf[i] = bm_result[i];
	}
	return Hp6_Send_CMD(tx_buf, rx_buf);
}

//�ر�Ѫѹ����
uint8_t BloodPre_Close(void)
{
	uint8_t i;
	for(i = 0; i < 24; i++)
	{
		tx_buf[i] = bm_close[i];
	}
	return Hp6_Send_CMD(tx_buf, rx_buf);
}

//�������ʲ���
uint8_t HeartBeat_Open(void)
{
	uint8_t i;
	for(i = 0; i < 24; i++)
	{
		rx_buf[i] = 0;
		tx_buf[i] = 0;
	}
	for(i = 0; i < 24; i++)
	{
		tx_buf[i] = hb_open[i];
	}
	return Hp6_Send_CMD(tx_buf, rx_buf);
}

//�õ����ʲ�������
uint8_t Get_HeartBeat_Result(void)
{
	uint8_t i;
	for(i = 0; i < 24; i++)
	{
		rx_buf[i] = 0;
		tx_buf[i] = 0;
	}
	for(i = 0; i < 24; i++)
	{
		tx_buf[i] = hb_result[i];
	}
	return Hp6_Send_CMD(tx_buf, rx_buf);
}

//�ر����ʲ���
uint8_t HeartBeat_Close(void)
{
	uint8_t i;
	for(i = 0; i < 24; i++)
	{
		tx_buf[i] = hb_close[i];
	}
	return Hp6_Send_CMD(tx_buf, rx_buf);
}

//�õ��������
void Get_Result(u8 *pData)
{
	uint8_t i = 0;
	for(i=0; i < 24; i++)
	{
		pData[i] = rx_buf[i];
	}
}
