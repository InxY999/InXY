#ifndef _HP6_H
#define _HP6_H

#include "stm32f4xx.h"
#include "Sys.h"


#define HP6_SCL_H   			  GPIO_SetBits(GPIOA, GPIO_Pin_2)
#define HP6_SCL_L           GPIO_ResetBits(GPIOA, GPIO_Pin_2)
#define HP6_SDA_H   			  GPIO_SetBits(GPIOA, GPIO_Pin_1)
#define HP6_SDA_L  	 			  GPIO_ResetBits(GPIOA, GPIO_Pin_1)
#define HP6_OFF     			  GPIO_SetBits(GPIOC, GPIO_Pin_13)
#define HP6_ON     				  GPIO_ResetBits(GPIOC, GPIO_Pin_13)
#define HP6_WRITE_ADDRESS   0XCC
#define HP6_READ_ADDRESS    0XCD

/*I2C��������*/
void HP6_I2C_Config(void);
void HP6_I2C_Start(uint8_t Delay);
void HP6_I2C_Stop(uint8_t Delay);
/*I2Cģ��ʱ��*/
uint8_t HP6_I2C_SendByte(uint8_t Byte,uint8_t Delay);
uint8_t HP6_I2C_RecvAck(uint8_t Delay);
uint8_t HP6_I2C_RecvByte(uint8_t ACK,uint8_t Delay);
void HP6_I2C_SendAck(uint8_t Status,uint8_t Delay);
uint16_t Crc16(uint8_t *data,uint16_t len);

void Hp_Start(uint8_t *pData);
void Hp_Recv_Data(uint8_t *pData);
uint8_t Hp_Send_CMD(uint8_t* tx_buf,uint8_t* rx_buf);
/*Ѫѹ��������*/
uint8_t BloodPre_Open(void);
uint8_t BloodPre_Close(void);
uint8_t Get_BloodPre_Result(void);
/*���ʲ�������*/
uint8_t HeartBeat_Open(void);
uint8_t HeartBeat_Close(void);
uint8_t Get_HeartBeat_Result(void);


void Get_Result(u8 *pData);

#endif /*Hp6.h*/

/*

******Ѫѹ����******
uint8_t bm_buf[128];
	BloodPre_Open();
	delay_ms(2560);
	uint8_t flag = 0;
	while(1)
	{
		Get_BloodPre_Result();
		Get_Result(bm_buf);
		if(bm_buf[7] == 0 )
		 {			
			 if(!flag)
			 {printf("measuring...\r\n"); }
			 flag =1;
		 }
		 else if(bm_buf[7] == 1)
		 {
				printf("High: %d  Low:%d\r\n",bm_buf[10],bm_buf[11]);
				BloodPre_Close();
		 }
		 else if(bm_buf[7] == 2)
		 {
			printf("measure error!\r\n");
			BloodPre_Close();
		 }
	}
*/


/*
*****���ʲ���*****
	uint8_t hb_buf[128];
	HeartBeat_Open();
	delay_ms(5000);
	uint8_t flag = 0;
	while(1)
	{
		Get_HeartBeat_Result();
		Get_Result(bm_buf);
		if(bm_buf[6] == 0)//���ʲ���δ����
		 {				 
				printf("Measuring Error\r\n"); 
				HeartBeat_Close();
		 }
		 else if(bm_buf[6] == 1)//���ʲ�������
		 {
				printf("Heart Beat: %d\r\n",bm_buf[7]);
				HeartBeat_Close();
		 }
	}
*/


