#include "Key.h"

void Key_GPIO_Config(void)
{
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA,ENABLE);//GPIOA RCCʹ��

	/*Key_Ok ->PA0*/
	GPIO_InitTypeDef GPIO_InitStruct;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN; //�˿�ģʽ������
	GPIO_InitStruct.GPIO_Pin	= GPIO_Pin_0;    // �˿ںţ�0
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL; //������ģʽ������
	GPIO_Init(GPIOA,&GPIO_InitStruct); //����ת��(���룡)
}
void ADC_CH3_GPIO_Config(void)
{
	Key_GPIO_Config();
	
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA,ENABLE);//GPIOA RCCʹ��
	/*Key_ADin ->PA3*/
	GPIO_InitTypeDef GPIO_InitStruct;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AN; //�˿�ģʽ������
	GPIO_InitStruct.GPIO_Pin	= GPIO_Pin_3;    // �˿ںţ�0
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL; //������ģʽ������
	GPIO_Init(GPIOA,&GPIO_InitStruct); //����ת��(���룡)
}

void ADC_CH3_Config(void)
{
	ADC_CH3_GPIO_Config();

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1,ENABLE);//ADC1 RCCʹ��
	/*ͨ������*/
	ADC_CommonInitTypeDef ADC_CommonInitStruct;
	ADC_CommonInitStruct.ADC_Mode					 		= ADC_Mode_Independent; //����ģʽ
  ADC_CommonInitStruct.ADC_Prescaler 				= ADC_Prescaler_Div4;
  ADC_CommonInitStruct.ADC_DMAAccessMode 		= ADC_DMAAccessMode_Disabled;
  ADC_CommonInitStruct.ADC_TwoSamplingDelay = ADC_TwoSamplingDelay_20Cycles;
	ADC_CommonInit(&ADC_CommonInitStruct);
	/*ADC1 CH3����*/
	ADC_InitTypeDef  ADC_InitStruct;
  ADC_InitStruct.ADC_Resolution 						= ADC_Resolution_12b;
  ADC_InitStruct.ADC_ScanConvMode 					= DISABLE;
  ADC_InitStruct.ADC_ContinuousConvMode 		= ENABLE;
  ADC_InitStruct.ADC_ExternalTrigConvEdge 	= ADC_ExternalTrigConvEdge_None;
  ADC_InitStruct.ADC_ExternalTrigConv 			= ADC_ExternalTrigConv_T1_CC3;
  ADC_InitStruct.ADC_DataAlign 							= ADC_DataAlign_Right;
  ADC_InitStruct.ADC_NbrOfConversion 				= 1;
	ADC_Init(ADC1,&ADC_InitStruct);//����
	
	ADC_ITConfig(ADC1,ADC_IT_EOC,ENABLE);
	NVIC_SetPriority(ADC_IRQn,NVIC_EncodePriority(7-2,0,2));
	NVIC_EnableIRQ(ADC_IRQn);
	
	ADC_RegularChannelConfig(ADC1,ADC_Channel_3,1,ADC_SampleTime_480Cycles);
	ADC_Cmd(ADC1,ENABLE);
	ADC_SoftwareStartConv(ADC1);
}

void ADC1_Check(void)
{
	static uint32_t adc_time = 0;
	if(SoftTimer(adc_time,10))
	{
		//printf("���������%d\r\n",ADC_GetConversionValue(ADC1));
		adc_time = GetCurrentTime();	
	}
}
uint8_t Key_Val = 0;
void Key_Scan(void) //���ఴ�������ж� (������)
{	
	if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0))
	{
		while(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0));
		Key_Val =5;
	}
}

/*
Left =4096(3.3v)  Right = 2048(1.65v)
Back =1365(1.1v)	Up = 1024(0.825v)
*/
void ADC_IRQHandler(void)
{
	if(ADC_GetFlagStatus(ADC1,ADC_FLAG_EOC))
	{
		ADC_ClearFlag(ADC1,ADC_FLAG_EOC);
	//	printf("%d\r\n",ADC_GetConversionValue(ADC1));
		if(ADC_GetConversionValue(ADC1) >500 )
		{
			if(ADC_GetConversionValue(ADC1)<1100)//500~1100 
			{
				Key_Val = 1;//Up Key
			}
			else// >1100
			{
				if(ADC_GetConversionValue(ADC1)<1500)//1100~1500
				{
					Key_Val = 3;//Back Key
				}
				else//>1500
				{
					if(ADC_GetConversionValue(ADC1)<3000)//1500~3000
					{
						Key_Val = 4;//Right Key
					}
					else//>3000
					{
						Key_Val = 2; //Left Key
					}
				}
			}
		}
		
	}
	
}


