#ifndef _KEY_H
#define _KEY_H


#include "stm32f4xx.h"

#include "Sys.h"
#include "Uart.h"
#include "Motor.h"

void ADC_GPIO_Config(void);
void ADC_CH3_GPIO_Config(void);
void ADC_CH3_Config(void);


void ADC1_Check(void);
void Key_Scan(void);

extern uint8_t Key_Val;

#endif /*KEY.h*/
