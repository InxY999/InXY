#ifndef _LED_H
#define _LED_H


#include "stm32f4xx.h"



void Led_Config(void);
void Led_On(void);
void Led_Off(void);



#endif /*Led.h*/
