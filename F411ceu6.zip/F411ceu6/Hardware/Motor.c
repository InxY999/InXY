#include "Motor.h"

void Motor_Config(void)
{
	/*Motor ->PB10*/
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB,ENABLE);
	/*�˿�����*/
	GPIO_InitTypeDef GPIO_InitStruct;
	GPIO_InitStruct.GPIO_Pin  = GPIO_Pin_10;
  GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOB,&GPIO_InitStruct);
	
}

void Motor_Work(void)
{
	GPIO_SetBits(GPIOB,GPIO_Pin_10);
	delay_ms(1000);
	GPIO_ResetBits(GPIOB,GPIO_Pin_10);
}


