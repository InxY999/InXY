#ifndef _MOTOR_H
#define _MOTOR_H


#include "stm32f4xx.h"
#include "Sys.h"

void Motor_Config(void);
void Motor_Work(void);


#endif /*Motor.h*/
