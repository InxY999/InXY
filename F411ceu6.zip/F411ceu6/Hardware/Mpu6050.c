#include "Mpu6050.h"


void MPU_I2C_Config(void)
{
	//��ʱ��
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC, ENABLE);
	//�������
	GPIO_InitTypeDef GPIO_InitStruct;
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_2;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStruct);
	//��©���
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_1;
	GPIO_InitStruct.GPIO_OType = GPIO_OType_OD;
	GPIO_Init(GPIOA, &GPIO_InitStruct);
	//ʹ��λ
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_13;
	GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
	GPIO_Init(GPIOC, &GPIO_InitStruct);
	
	GPIO_SetBits(GPIOA, GPIO_Pin_2);
	GPIO_SetBits(GPIOA, GPIO_Pin_1);
	GPIO_ResetBits(GPIOC,GPIO_Pin_13);
}

void MPU_I2C_Start(uint8_t Delay)
{	
	delay_us(Delay);
	MPU_SCL_H;
	MPU_SDA_H;
	delay_us(Delay);
	MPU_SDA_L;
	delay_us(Delay);
	MPU_SCL_L;//����SCL��ȷ��ʱ��ȫ
}

void MPU_I2C_Stop(uint8_t Delay)
{	
	MPU_SDA_L;
	delay_us(Delay);
	MPU_SCL_H;
	delay_us(Delay);
	MPU_SDA_H;
	delay_us(Delay);
}

void MPU_I2C_SendAck(uint8_t Status,uint8_t Delay)
{	
	MPU_SCL_L;
	if(Status)
	{	
		MPU_SDA_H;
	}
	else			
	{	
		MPU_SDA_L;
	}
	delay_us(Delay);
	MPU_SCL_H;
	delay_us(Delay);
	MPU_SCL_L;
}

uint8_t MPU_I2C_RecvAck(uint8_t Delay)
{
	uint8_t ACK = 0;
	MPU_SDA_H;//��©���ͷ�����  �������ٿ���������
	MPU_SCL_L;//����ʱ����
	delay_us(Delay);
	MPU_SCL_H;//����ʱ����
	if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_1))
	{
		ACK = 1;
	}
	delay_us(Delay);
	MPU_SCL_L;
	return ACK;
}

uint8_t MPU_I2C_SendByte(uint8_t Byte,uint8_t Delay)
{
	uint8_t i,ACK;
	for(i = 0; i < 8; i++)
	{
		MPU_SCL_L;
		if(Byte & (0x80>>i))
			MPU_SDA_H;
		else								
			MPU_SDA_L;
		delay_us(Delay);
		MPU_SCL_H;
		delay_us(5);
	}
	MPU_SCL_L;
	ACK = MPU_I2C_RecvAck(Delay);
	return ACK;
}

uint8_t MPU_I2C_RecvByte(uint8_t ACK,uint8_t Delay)
{
	uint8_t Byte = 0 ,i;
	MPU_SDA_H;//�����ͷ����ߣ��ӻ���������
	for(i = 0; i < 8; i++)
	{
		MPU_SCL_L;
		delay_us(Delay);
		MPU_SCL_H;
		Byte <<=1;
		if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_1))
		{
			Byte |= 1;
		}
		delay_us(Delay);
	}
	MPU_SCL_H;
	MPU_I2C_SendAck(ACK,Delay);
	return Byte;
}
