#ifndef _Mpu6050_H
#define _Mpu6050_H

#include "stm32f4xx.h"
#include "Delay.h"


#define MPU_SCL_H   			  GPIO_SetBits(GPIOA, GPIO_Pin_2)
#define MPU_SCL_L           GPIO_ResetBits(GPIOA, GPIO_Pin_2)
#define MPU_SDA_H   			  GPIO_SetBits(GPIOA, GPIO_Pin_1)
#define MPU_SDA_L  	 			  GPIO_ResetBits(GPIOA, GPIO_Pin_1)
#define MPU_OFF     			  GPIO_SetBits(GPIOC, GPIO_Pin_13)
#define MPU_ON     				  GPIO_ResetBits(GPIOC, GPIO_Pin_13)
#define MPU_WRITE_ADDRESS   0XCC
#define MPU_READ_ADDRESS    0XCD


void MPU_I2C_Config(void);
void MPU_I2C_Start(uint8_t Delay);
void MPU_I2C_Stop(uint8_t Delay);
void MPU_I2C_SendAck(uint8_t Status,uint8_t Delay);
uint8_t MPU_I2C_RecvAck(uint8_t Delay);
uint8_t MPU_I2C_SendByte(uint8_t Byte,uint8_t Delay);
uint8_t MPU_I2C_RecvByte(uint8_t ACK,uint8_t Delay);




#endif /*Mpu6050.h*/

