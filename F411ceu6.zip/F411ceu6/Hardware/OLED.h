#ifndef _OLED_H
#define _OLED_H

#define Soft_SPI  0

#include "stm32f4xx.h"
#include "Sys.h"
#include "Char_Library.h"

void OLED_GPIO_Config(void);
void OLED_Rst(void);
void OLED_Config(void);
//void OLED_SendByte(uint8_t Byte);
//void OLED_SendByte(uint8_t Byte);
void OLED_SendCmd(uint8_t Cmd);
void OLED_Fill(void);
void OLED_Clear(void);
void OLED_Clear_Page(uint8_t Start,uint8_t Eed);
void OLED_SetPos(uint8_t Col,uint8_t Page);
void OLED_Show16HanZi(uint8_t Col,uint8_t Page,uint8_t *phz);
void OLED_Show24Hz(uint8_t Col,uint8_t Page, uint8_t * phz);
void OLED_Show32Hz(uint8_t Col,uint8_t Page, uint8_t * phz);
void OLED_Show16Asc(uint8_t Col,uint8_t Page, uint8_t * Ascii_Ptr);
void OLED_Show24Asc(uint8_t Col,uint8_t Page, uint8_t * Ascii_Ptr);
void OLED_Show32Asc(uint8_t Col,uint8_t Page, uint8_t * Ascii_Ptr);
void OLED_ShowAscString(uint8_t Col,uint8_t Page, uint8_t *Ptr);
void OLED_Show16String1(uint8_t Col,uint8_t Page,uint32_t cnt,uint8_t *phz);
void OLED_Show16String(uint8_t Col,uint8_t Page,uint32_t cnt,uint8_t *phz);
void OLED_ShowPicture(uint8_t Addr_x,uint8_t Addr_y,uint8_t wide,uint8_t high,uint8_t *str);

uint16_t OLED_SendByte(uint8_t Byte);






#endif /*OLED.h*/
