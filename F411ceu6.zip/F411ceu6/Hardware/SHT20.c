#include "SHT20.h"


void SHT20_I2C_Config(void)
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_I2C1,ENABLE);//I2C RCCʹ��
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB,ENABLE);//GPIOB RCCʹ��

	/*I2C ->SCL ->PB8*/
	GPIO_InitTypeDef GPIO_InitStruct ={0};
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_InitStruct.GPIO_Pin	= GPIO_Pin_8;    // �˿ںţ�8
  GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStruct.GPIO_OType = GPIO_OType_OD;
  GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOB,&GPIO_InitStruct); //����ת��(����!)
	/*I2C ->SDA ->PB9*/
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_InitStruct.GPIO_Pin	= GPIO_Pin_9;    // �˿ںţ�9
  GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStruct.GPIO_OType = GPIO_OType_OD;
  GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOB,&GPIO_InitStruct); //����ת��(����!)

//	GPIO_PinAFConfig(GPIOB,GPIO_PinSource8,GPIO_AF_I2C1);
//	GPIO_PinAFConfig(GPIOB,GPIO_PinSource9,GPIO_AF_I2C1);

//	/*I2C����*/
//	I2C_InitTypeDef I2C_InitStruct;
//  I2C_InitStruct.I2C_ClockSpeed = 100000;
//	I2C_InitStruct.I2C_Mode = I2C_Mode_I2C;
//  I2C_InitStruct.I2C_DutyCycle = I2C_DutyCycle_2;
//  I2C_InitStruct.I2C_OwnAddress1 = I2C_AcknowledgedAddress_7bit;
//  I2C_InitStruct.I2C_Ack = I2C_Ack_Enable;
//  I2C_InitStruct.I2C_AcknowledgedAddress = I2C_AcknowledgedAddress_7bit;
//	I2C_Init(I2C1,&I2C_InitStruct);
//	I2C_Cmd(I2C1,ENABLE);
}

void SHT20_I2C_Start(void)
{	
	SHT20_SDA_H;
	delay_ms(5);
	SHT20_SCL_H;
	delay_ms(5);
	
	SHT20_SDA_L;
	delay_ms(5);
	
	SHT20_SCL_L;//����SCL��ȷ��ʱ��ȫ
}

void SHT20_I2C_Stop(void)
{	
	SHT20_SDA_L;
	SHT20_SCL_L;
	delay_ms(5);
	SHT20_SCL_H;
	delay_ms(5);

	SHT20_SDA_H;
	delay_ms(5);
}

void SHT20_I2C_SendByte(uint8_t Byte)
{
	SHT20_SCL_L;
	delay_ms(5);
	for(uint8_t i=0;i<8;i++)
	{
		if(Byte & (0x80>>i))
		{
			SHT20_SDA_H;
		}
		else
		{
			SHT20_SDA_L;
		}
		delay_ms(5);
		SHT20_SCL_H;
		delay_ms(5);
		SHT20_SCL_L;
	}
}

ACK_Status SHT20_I2C_RecvAck(void)
{
	ACK_Status ACK = NAck;
	SHT20_SDA_H;//��©���ͷ�����  �������ٿ���������
	SHT20_SCL_L;//����ʱ����
	delay_ms(5);
	SHT20_SCL_H;//����ʱ����
	delay_ms(5);
	if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_9))
	{
		ACK = NAck;
	}
	else if(!GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_9))
	{
		ACK = Ack;
	}
	SHT20_SCL_L;
	delay_ms(5);
	return ACK;
}

uint8_t SHT20_I2C_RecvByte(void)
{
	uint8_t Byte = 0;
	SHT20_SDA_H;//�����ͷ����ߣ��ӻ���������
	for(uint8_t i=0;i<8;i++)
	{
		SHT20_SCL_L;
		delay_ms(5);
		SHT20_SCL_H;
		if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_9))
		{
			Byte |= 1<<(7-i);
		}
		else if(!GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_9))
		{
			Byte &=~(1<<(7-i));
		}
	}
	SHT20_SCL_L;
	return Byte;
}

void SHT20_I2C_SendAck(ACK_Status Status)
{	
	SHT20_SCL_L;
	SHT20_SDA_L;
	delay_ms(5);
	if(Status == NAck)
	{
		SHT20_SDA_H;
		delay_ms(5);	
	}
	else if(Status == Ack)
	{
		SHT20_SDA_L;
		delay_ms(5);
	}
	SHT20_SCL_H;
	delay_ms(5);
	SHT20_SCL_L;
}

uint16_t Temp = 0,Humi =0;
void SHT20_GetTem(void)
{
	uint8_t Temp_H = 0,Temp_L= 0;
	float Temp_Real = 0;

	uint8_t tmp = NAck,Temp_Check = 0;
	SHT20_I2C_Start();
	SHT20_I2C_SendByte(SHT20_AddrW);
	while(tmp != Ack){tmp = SHT20_I2C_RecvAck();}
	tmp= 1;
	SHT20_I2C_SendByte(Tem_NHostMaster);
	while(tmp != Ack){tmp = SHT20_I2C_RecvAck();}
	tmp = 1;
	while(tmp != Ack)
	{
		SHT20_I2C_Start();
		SHT20_I2C_SendByte(SHT20_AddrR);
		tmp = SHT20_I2C_RecvAck();
	}
	tmp = 1;
	Temp_H |= SHT20_I2C_RecvByte();
	SHT20_I2C_SendAck(Ack);
	Temp_L |= SHT20_I2C_RecvByte()>>2<<2;
	SHT20_I2C_SendAck(Ack);
	Temp_Check |=SHT20_I2C_RecvByte();
	SHT20_I2C_SendAck(NAck);
	SHT20_I2C_Stop();

	Temp = Temp_H<<8|Temp_L;
	Temp_Real = 175.72 * (Temp /65536.0) - 46.85;
	printf("Temp_Real = %.2f��\r\n",Temp_Real);
}

void SHT20_GetHum(void)
{
	uint16_t Humi = 0;
	float Humi_Real = 0;
	uint8_t tmp =NAck,Humi_Check = 0;
	SHT20_I2C_Start();
	SHT20_I2C_SendByte(SHT20_AddrW);
	while(tmp != Ack){tmp = SHT20_I2C_RecvAck();}
	tmp= 1;
	SHT20_I2C_SendByte(Hum_NHostMaster);
	while(tmp != Ack){tmp = SHT20_I2C_RecvAck();}
	tmp = 1;
	while(tmp != Ack)
	{
		SHT20_I2C_Start();
		SHT20_I2C_SendByte(SHT20_AddrR);
		tmp = SHT20_I2C_RecvAck();
	}
	tmp = 1;
	Humi |= SHT20_I2C_RecvByte()<<8;
	SHT20_I2C_SendAck(Ack);
	Humi |= SHT20_I2C_RecvByte()>>4<<4;
	SHT20_I2C_SendAck(Ack);
	Humi_Check |=SHT20_I2C_RecvByte();
	SHT20_I2C_SendAck(NAck);
	SHT20_I2C_Stop();
	
	Humi_Real = 125 * (Humi /65536.0) - 6;
	printf("Humi_Real = %.2f%%\r\n",Humi_Real);
}

/*
	SHT20���õ���CRC8У�顢ģ��ΪX8 + X5 +X4 +1����CRC_MODEL = 0x131��CRCУ��Ĵ�������
*/
uint8_t data[3]={0x55,0x25,0x00};
#define CRC_MODEL 0x131
uint8_t CRC_Check(uint8_t *ptr, uint8_t len)
{
    uint8_t i; 
    uint8_t crc = 0x00; 		//����ĳ�ʼcrcֵ 
    while(len--)
    {
			crc ^= *ptr++;  		//ÿ��������Ҫ������������,������ָ����һ����  
			for (i = 8; i > 0; --i) //������μ�����������һ���ֽ�crcһ�� 
			{ 
				if (crc & 0x80)
				{
					crc = (crc << 1) ^ CRC_MODEL;
				}
				else
				crc = (crc << 1);
			}
    }
		return crc;
}

