#ifndef _SHT20_H
#define _SHT20_H


#include "stm32f4xx.h"
#include "Sys.h"


#define SHT20_SDA_H      	GPIO_SetBits(GPIOB,GPIO_Pin_9)
#define SHT20_SDA_L				GPIO_ResetBits(GPIOB,GPIO_Pin_9)
#define SHT20_SCL_H				GPIO_SetBits(GPIOB,GPIO_Pin_8)
#define SHT20_SCL_L				GPIO_ResetBits(GPIOB,GPIO_Pin_8)

#define SHT20_AddrW						0x80
#define SHT20_AddrR						0x81

#define Tem_HostMaster 				0xE3
#define Hum_HostMaster 				0xE5
#define Tem_NHostMaster 			0XF3
#define Hum_NHostMaster 			0XF5

#define Soft_Rst							0XFE

#define Write_Reg							0XE6
#define Read_Reg							0XE7

typedef enum
{
	Ack  = 0, //Ӧ��0
	NAck = 1,	//Ӧ���
}ACK_Status;

extern uint16_t Temp,Humi;

void SHT20_I2C_Config(void);
void SHT20_I2C_Start(void);
void SHT20_I2C_Stop(void);
void SHT20_I2C_SendByte(uint8_t Byte);
ACK_Status SHT20_I2C_RecvAck(void);
uint8_t SHT20_I2C_RecvByte(void);
void SHT20_I2C_SendAck(ACK_Status Status);

void SHT20_GetTem(void);
void SHT20_GetHum(void);


#endif /*SHT20.h*/
