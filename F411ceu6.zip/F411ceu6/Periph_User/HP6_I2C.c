#include "HP6_I2C.h"


void HP6_I2C_Config(void)
{
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA,ENABLE);//GPIOB RCCʹ��
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC,ENABLE);
	/*HP6_I2C ->SCL ->PA2*/
	GPIO_InitTypeDef GPIO_InitStruct ={0};
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_InitStruct.GPIO_Pin	= GPIO_Pin_2;    // �˿ںţ�2
  GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_Init(GPIOA,&GPIO_InitStruct); //����ת��(����!)
	/*HP6_I2C ->SDA ->PA1*/
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_InitStruct.GPIO_Pin	= GPIO_Pin_1;    // �˿ںţ�1
  GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStruct.GPIO_OType = GPIO_OType_OD;
  GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_Init(GPIOA,&GPIO_InitStruct); //����ת��(����!)
	/*HP6_I2C ->EN ->PC13*/
	GPIO_InitStruct.GPIO_Pin  = GPIO_Pin_13;	 // �˿ںţ�13
  GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStruct.GPIO_Speed = GPIO_Speed_100MHz;
  GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_Init(GPIOC,&GPIO_InitStruct);
	
	GPIO_SetBits(GPIOA, GPIO_Pin_2);
	GPIO_SetBits(GPIOA, GPIO_Pin_1);
	GPIO_ResetBits(GPIOC,GPIO_Pin_13);
}

void HP6_I2C_Start(void)
{	
	Delay_Us(5);
	HP6_SCL_H;
	HP6_SDA_H;
	Delay_Us(5);
	HP6_SDA_L;
	Delay_Us(5);
	
	HP6_SCL_L;//����SCL��ȷ��ʱ��ȫ
}

void HP6_I2C_Stop(void)
{	
	HP6_SDA_L;
	Delay_Us(5);
	HP6_SCL_H;
	Delay_Us(5);

	HP6_SDA_H;
	Delay_Us(5);
}

void HP6_I2C_SendByte(uint8_t Byte)
{
	HP6_SCL_L;
	Delay_Us(5);
	for(uint8_t i=0;i<8;i++)
	{
		if(Byte & (0x80>>i))
		{
			HP6_SDA_H;
		}
		else
		{
			HP6_SDA_L;
		}
		Delay_Us(5);
		HP6_SCL_H;
		Delay_Us(5);
		HP6_SCL_L;
	}
}

ACK_Status HP6_I2C_RecvAck(void)
{
	ACK_Status ACK = NAck;
	HP6_SDA_H;//��©���ͷ�����  �������ٿ���������
	HP6_SCL_L;//����ʱ����
	Delay_Us(5);
	HP6_SCL_H;//����ʱ����
	if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_1))
	{
		ACK = NAck;
	}
	else if(!GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_1))
	{
		ACK = Ack;
	}	
	Delay_Us(5);
	HP6_SCL_L;
	return ACK;
}

uint8_t HP6_I2C_RecvByte(void)
{
	uint8_t Byte = 0;
	HP6_SDA_H;//�����ͷ����ߣ��ӻ���������
	for(uint8_t i=0;i<8;i++)
	{
		HP6_SCL_L;
		Delay_Us(5);
		HP6_SCL_H;
		if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_1))
		{
			Byte |= 1<<(7-i);
		}
		else if(!GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_1))
		{
			Byte &=~(1<<(7-i));
		}
	}
	HP6_SCL_L;
	return Byte;
}

void HP6_I2C_SendAck(ACK_Status Status)
{	
	HP6_SCL_L;
//HP6_SDA_L;
//	Delay_Ms(10);
	if(Status == NAck)
	{
		HP6_SDA_H;
		Delay_Us(5);	
	}
	else if(Status == Ack)
	{
		HP6_SDA_L;
		Delay_Us(5);
	}
	HP6_SCL_H;
	Delay_Us(5);
	HP6_SCL_L;
}

