#ifndef _HP6_I2C_H
#define _HP6_I2C_H


#include "stm32f4xx.h"
#include "Sys.h"
#include "SHT20_I2C.h"



void HP6_I2C_Config(void);
void HP6_I2C_Start(void);
void HP6_I2C_Stop(void);
void HP6_I2C_SendByte(uint8_t Byte);
ACK_Status HP6_I2C_RecvAck(void);
uint8_t HP6_I2C_RecvByte(void);
void HP6_I2C_SendAck(ACK_Status Status);


#endif /*HP6_I2C.h*/

