#include "Rtc.h"

	RTC_InitTypeDef 		RTC_InitStruct;
	RTC_DateTypeDef		 	RTC_DateStruct;
	RTC_AlarmTypeDef	 	RTC_AlarmStruct;
	RTC_TimeTypeDef   	RTC_TimeStruct;
	EXTI_InitTypeDef    EXTI17_InitStruct;
	RTC_TimeTypeDef 		RTC_TimeValue;
	RTC_DateTypeDef 		RTC_DateValue;
	
void RTC_Config(void)
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR,ENABLE);//��PWRʱ��
	PWR_BackupAccessCmd(ENABLE);//ʹ�ܱ��ݼĴ�������
	RTC_WriteProtectionCmd(DISABLE); //�ر�д����

	RCC_LSICmd(ENABLE); //��LSI
	while(RCC_GetFlagStatus(RCC_FLAG_LSIRDY) == RESET);//�ȴ�LSI�ȶ�
	RCC_RTCCLKConfig(RCC_RTCCLKSource_LSI);//ѡ��LSI
	RCC_RTCCLKCmd(ENABLE);
	
	RTC_InitStruct.RTC_HourFormat 	= RTC_HourFormat_24;
	RTC_InitStruct.RTC_AsynchPrediv = 0x7F;
	RTC_InitStruct.RTC_SynchPrediv 	= 0xFF; 
	RTC_Init(&RTC_InitStruct);
	
//	RTC_Set_Date(23,13,39,2);//__DATE__	/*�������ں�ʱ��*/
//	RTC_Set_Time(16,53,30,RTC_H12_AM); //__TIME__  /*�������ں�ʱ��*/	
}
uint32_t Hour_More = 0;
uint8_t AmPm = 0;
ErrorStatus RTC_Set_Time(uint8_t Hour,uint8_t Min,uint8_t Sec,uint8_t AP)
{

	if(Sec>60){uint32_t Sec_More = 0; Sec_More = Sec/60;Min+=Sec_More;Sec%=60;}
	if(Min>60){uint32_t Min_More = 0;Min_More = Min/60;Hour+=Min_More;Min%=60;}
	if(Hour>24){Hour_More = Hour/24;Hour&=24;	}
	RTC_TimeTypeDef   	RTC_TimeStruct = {0};
  RTC_TimeStruct.RTC_H12 = AP;
  RTC_TimeStruct.RTC_Hours = Hour;
  RTC_TimeStruct.RTC_Minutes = Min;
  RTC_TimeStruct.RTC_Seconds = Sec; 
	return RTC_SetTime(RTC_Format_BIN,&RTC_TimeStruct);
}

ErrorStatus RTC_Set_Date(uint16_t Year,uint8_t Month,uint8_t Day,uint8_t Week)
{
	Day+=Hour_More;
	if(Day>31){uint32_t Day_More = 0;Day_More = Day/31;Month+=Day_More;Day%=31;}
	if(Month>12){uint32_t Month_More = 0;Month_More = Month/12;Year+=Month_More;Month%=12;}

	RTC_DateTypeDef RTC_DateStruct ={0};
	
	RTC_DateStruct.RTC_WeekDay = Week;
  RTC_DateStruct.RTC_Date = Day;
  RTC_DateStruct.RTC_Month = Month;
  RTC_DateStruct.RTC_Year = Year;
	return RTC_SetDate(RTC_Format_BIN,&RTC_DateStruct);
}

void RTC_Set_AlarmA(uint8_t Week,uint8_t Hour,uint8_t Min,uint8_t Sec)
{
	RTC_AlarmCmd(RTC_Alarm_A,DISABLE); //�ȹر�����A
	
  RTC_TimeStruct.RTC_H12 = RTC_H12_AM;
  RTC_TimeStruct.RTC_Hours = Hour;
  RTC_TimeStruct.RTC_Minutes = Min;
  RTC_TimeStruct.RTC_Seconds = Sec; 
	
  RTC_AlarmStruct.RTC_AlarmDateWeekDaySel = RTC_AlarmDateWeekDaySel_Date;
  RTC_AlarmStruct.RTC_AlarmDateWeekDay = Week;
  RTC_AlarmStruct.RTC_AlarmMask = RTC_AlarmMask_None;
	RTC_AlarmStruct.RTC_AlarmTime = RTC_TimeStruct;
	RTC_SetAlarm(RTC_Format_BIN,RTC_Alarm_A,&RTC_AlarmStruct);
	//ʹ������A���ж�
	RTC_ITConfig(RTC_IT_ALRA,ENABLE);
	//��������A
	RTC_AlarmCmd(RTC_Alarm_A,ENABLE);
	//�ж�������
	EXTI17_InitStruct.EXTI_Line = EXTI_Line17;
	EXTI17_InitStruct.EXTI_LineCmd = ENABLE;
	EXTI17_InitStruct.EXTI_Mode = EXTI_Mode_Interrupt ;
	EXTI17_InitStruct.EXTI_Trigger = EXTI_Trigger_Rising ;
	EXTI_Init(&EXTI17_InitStruct); 
	
	NVIC_SetPriority(RTC_Alarm_IRQn,NVIC_EncodePriority(7-2,1,0));
}

uint32_t RTC_Data[6]= {0};
void RTC_Test(void)
{
	//1.��ȡ����
	RTC_GetDate(RTC_Format_BIN,&RTC_DateValue);
	printf("Date:%d-%02d-%02d ����%d \r\n",RTC_Data[0],RTC_DateValue.RTC_Month,RTC_DateValue.RTC_Date,RTC_DateValue.RTC_WeekDay);
	//2.��ȡʱ��
	RTC_GetTime(RTC_Format_BIN,&RTC_TimeValue);
	printf("Time:%02d:%02d:%02d",RTC_TimeValue.RTC_Hours,RTC_TimeValue.RTC_Minutes,RTC_TimeValue.RTC_Seconds);
	if(AmPm ==0x00)
	{
		printf("\tAM\r\n");
	}
	else{printf("\tPM\r\n");}
}

uint8_t CaculateWeekDay(int Year,int Month, int Day)
{
	uint8_t tmp =0xFF;
	if(Month==1||Month==2) {
			Month+=12;
			Year--;
	}
	int iWeek=(Day+2*Month+3*(Month+1)/5+Year+Year/4-Year/100+Year/400)%7;
	switch(iWeek)
	{
		case 0: tmp = 1;break;
		case 1: tmp = 2;break;
		case 2: tmp = 3;break;
		case 3: tmp = 4;break;
		case 4: tmp = 5;break;
		case 5: tmp = 6;break;
		case 6: tmp = 7;break;
	}
	return tmp;
}

//�����жϷ�����
void RTC_Alarm_IRQHandler()
{
	//�ж��ж��Ƿ���
	if(RTC_GetITStatus(RTC_IT_ALRA)==SET)
	{
		RTC_ClearITPendingBit(RTC_IT_ALRA);//���жϱ�־λ
		Motor_Work();
	}
	EXTI_ClearITPendingBit(EXTI_Line17);
}

//	uint8_t RTC_Flag = 0;//0��ʾ���絽������ȣ�12������1��ʾ��ҹ���賿���ȣ�12������
//	uint8_t Date_UpDate = 0;

//		/*���ڽ�������ʱ�䣬ʹ��RTC*/
//		if(Usart1_recv.recvflag)
//		{		
//			memset(RTC_Data,0,24);
//			uint32_t Start_flag=0,tmp=0;
//			uint8_t cnt = 0,i=0;
//			for(i=0;i<64;i++)
//			{
//				if((Usart1_recv.recvbuff[i] ==',') ||(Usart1_recv.recvbuff[i] == '\0'))
//				{
//					tmp = i;
//					for(i=Start_flag;i<tmp;i++)
//					{
//						RTC_Data[cnt] +=(Usart1_recv.recvbuff[i]-48)*pow(10,tmp-1-i);
//					}
//					cnt++;
//					Start_flag = tmp + 1;
//				}
//				Usart1_recv.recvflag = 0;
//				Usart1_recv.recvcnt = 0; //�ط��ַ�����
//				if(cnt == 6)break;
//			}
//				if(RTC_Data[3]>12 && !RTC_Flag){RTC_Flag =1;RTC_Data[3]-=12;AmPm = 0x40;}//���絽�������
//				else if(RTC_Data[3]==12 && RTC_Flag){RTC_Flag = 0;RTC_Data[3]-=12;AmPm = 0x00;}//�������賿����
//				else if(RTC_Data[3]<12){RTC_Flag = 0;AmPm = 0x00;}
//				
//				RTC_Set_Time(RTC_Data[3],RTC_Data[4],RTC_Data[5],AmPm);
//				RTC_Set_Date(RTC_Data[0],RTC_Data[1],RTC_Data[2],CaculateWeekDay(RTC_Data[0],RTC_Data[1],RTC_Data[2]));
//				Date_UpDate = 1;
//		}
//		if(Date_UpDate)
//		{
//			RTC_Test();
//			delay_ms(1000);
//		}

