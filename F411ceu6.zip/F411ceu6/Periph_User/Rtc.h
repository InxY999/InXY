#ifndef _RTC_H
#define _RTC_H


#include "stm32f4xx.h"
#include <stdio.h>
#include "Sys.h"
#include "Motor.h"

extern uint32_t Hour_More;
extern uint32_t RTC_Data[6];
extern uint8_t AmPm;

void RTC_Config(void);
void RTC_Test(void);
ErrorStatus RTC_Set_Time(uint8_t Hour,uint8_t Min,uint8_t Sec,uint8_t AmPm);
ErrorStatus RTC_Set_Date(uint16_t Year,uint8_t Month,uint8_t Day,uint8_t Week);
uint8_t CaculateWeekDay(int Year,int Month, int Day);

#endif /*Rtc.h*/
