#include "SHT20_I2C.h"


void SHT20_I2C_Config(void)
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_I2C1,ENABLE);//I2C RCCʹ��
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB,ENABLE);//GPIOB RCCʹ��

	/*I2C ->SCL ->PB8*/
	GPIO_InitTypeDef GPIO_InitStruct ={0};
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_InitStruct.GPIO_Pin	= GPIO_Pin_8;    // �˿ںţ�8
  GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStruct.GPIO_OType = GPIO_OType_OD;
  GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOB,&GPIO_InitStruct); //����ת��(����!)
	/*I2C ->SDA ->PB9*/
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_InitStruct.GPIO_Pin	= GPIO_Pin_9;    // �˿ںţ�9
  GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStruct.GPIO_OType = GPIO_OType_OD;
  GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOB,&GPIO_InitStruct); //����ת��(����!)

//	GPIO_PinAFConfig(GPIOB,GPIO_PinSource8,GPIO_AF_I2C1);
//	GPIO_PinAFConfig(GPIOB,GPIO_PinSource9,GPIO_AF_I2C1);

//	/*I2C����*/
//	I2C_InitTypeDef I2C_InitStruct;
//  I2C_InitStruct.I2C_ClockSpeed = 100000;
//	I2C_InitStruct.I2C_Mode = I2C_Mode_I2C;
//  I2C_InitStruct.I2C_DutyCycle = I2C_DutyCycle_2;
//  I2C_InitStruct.I2C_OwnAddress1 = I2C_AcknowledgedAddress_7bit;
//  I2C_InitStruct.I2C_Ack = I2C_Ack_Enable;
//  I2C_InitStruct.I2C_AcknowledgedAddress = I2C_AcknowledgedAddress_7bit;
//	I2C_Init(I2C1,&I2C_InitStruct);
//	I2C_Cmd(I2C1,ENABLE);
}

void SHT20_I2C_Start(void)
{	
	SHT20_SDA_H;
	Delay_Ms(5);
	SHT20_SCL_H;
	Delay_Ms(5);
	
	SHT20_SDA_L;
	Delay_Ms(5);
	
	SHT20_SCL_L;//����SCL��ȷ��ʱ��ȫ
}

void SHT20_I2C_Stop(void)
{	
	SHT20_SDA_L;
	SHT20_SCL_L;
	Delay_Ms(5);
	SHT20_SCL_H;
	Delay_Ms(5);

	SHT20_SDA_H;
	Delay_Ms(5);
}

void SHT20_I2C_SendByte(uint8_t Byte)
{
	SHT20_SCL_L;
	Delay_Ms(5);
	for(uint8_t i=0;i<8;i++)
	{
		if(Byte & (0x80>>i))
		{
			SHT20_SDA_H;
		}
		else
		{
			SHT20_SDA_L;
		}
		Delay_Ms(5);
		SHT20_SCL_H;
		Delay_Ms(5);
		SHT20_SCL_L;
	}
}

ACK_Status SHT20_I2C_RecvAck(void)
{
	ACK_Status ACK = NAck;
	SHT20_SDA_H;//��©���ͷ�����  �������ٿ���������
	SHT20_SCL_L;//����ʱ����
	Delay_Ms(5);
	SHT20_SCL_H;//����ʱ����
	Delay_Ms(5);
	if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_9))
	{
		ACK = NAck;
	}
	else if(!GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_9))
	{
		ACK = Ack;
	}
	SHT20_SCL_L;
	Delay_Ms(5);
	return ACK;
}

uint8_t SHT20_I2C_RecvByte(void)
{
	uint8_t Byte = 0;
	SHT20_SDA_H;//�����ͷ����ߣ��ӻ���������
	for(uint8_t i=0;i<8;i++)
	{
		SHT20_SCL_L;
		Delay_Ms(5);
		SHT20_SCL_H;
		if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_9))
		{
			Byte |= 1<<(7-i);
		}
		else if(!GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_9))
		{
			Byte &=~(1<<(7-i));
		}
	}
	SHT20_SCL_L;
	return Byte;
}

void SHT20_I2C_SendAck(ACK_Status Status)
{	
	SHT20_SCL_L;
	SHT20_SDA_L;
	Delay_Ms(5);
	if(Status == NAck)
	{
		SHT20_SDA_H;
		Delay_Ms(5);	
	}
	else if(Status == Ack)
	{
		SHT20_SDA_L;
		Delay_Ms(5);
	}
	SHT20_SCL_H;
	Delay_Ms(5);
	SHT20_SCL_L;
}

