#include "Sys.h"


void Delay_base(void)
{
	__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
	__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
	__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
	__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
	__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
	__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
	__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
	__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
	__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();__NOP();
}

//void delay_ms(uint32_t nms)
//{
//	for(uint32_t i=0;i<nms;i++)
//	{
//		for(uint32_t j=0;j<1000;j++)
//		{
//				Delay_base();
//		}
//	}
//}

//void delay_us(uint32_t nus)
//{
//	for(uint32_t i=0;i<nus;i++)
//	{
//		Delay_base();
//	}
//}

void MySystick_Config(void)
{
	SysTick_Config(SystemCoreClock /1000);
}

uint8_t Hse_Clock_Init(uint32_t pllm,uint32_t plln,uint32_t pllp,uint32_t pllq)
{
	uint32_t counter = 0;
	uint8_t	 status  = 0;

	RCC->CR |= 1 << 16;//HSEʹ��
	//�ȴ�HSEʱ�Ӿ���
	while((((1 << 17)& RCC->CR) == 0) && (counter != 0x5000))
	{
		counter++;
	}
	if(counter == 0x5000)//HSEʱ�Ӿ���ʧ��
	{
		status = 1;
	}
	else
	{
		RCC->APB1ENR |= 1 << 28;//ʹ�ܵ�Դ�ӿ�ʱ��
		PWR->CR |= 3 << 14;//VOS = 1 HCLK�����Ƶ��168����

		//������ط�Ƶ���Ӻͱ�Ƶ����
		RCC->CFGR &= ~(1<<7);
		RCC->CFGR |= 5 << 10;
		RCC->CFGR |= 4 << 13;

		RCC->PLLCFGR |= pllm;
		RCC->PLLCFGR |= plln << 6;
		RCC->PLLCFGR |= ((pllp >> 1) - 1) << 16;
		RCC->PLLCFGR |= pllq <<24;

		RCC->CR |= 1<< 22;
		RCC->CR |= 1<< 24; //ʹ��PLL

		//�ȴ�PLLʱ�Ӿ���
		counter = 0;
		while((((1 << 25)& RCC->CR) == 0) && (counter != 0x5000))
		{
			counter++;
		}
		if(counter == 0x5000)//PLLʱ�Ӿ���ʧ��
		{
			status = 2;
		}

		FLASH->ACR |= 1 << 8;//ʹ��Ԥȡ
		FLASH->ACR |= 1 << 9;
		FLASH->ACR |= 1 << 10;
		FLASH->ACR |= 5 << 0;

		RCC->CFGR &= ~(3 << 0);//Ĭ��ѡ���ڲ�ʱ��
		RCC->CFGR |= 2 << 0;
		counter = 0;
		while((((3 << 2)& RCC->CFGR) != 8) && (counter != 0x5000))
		{
			counter++;
		}
		if(counter == 0x5000)//PLLʱ�Ӿ���ʧ��
		{
			status = 3;
		}
	}

	return status;
}

uint32_t SystemTime = 0;

uint32_t GetCurrentTime(void)
{
	return SystemTime;
}

uint32_t SysTime(void)
{
	return SystemTime;
}

//�Ż�֮��Ĵ���
uint8_t SoftTimer(uint32_t BaseTime,uint32_t Timeout)
{
	if(SystemTime>=BaseTime)
		return (SystemTime-BaseTime)>=Timeout;
	return (SystemTime+0xFFFFFFFF-BaseTime)>=Timeout;
}

uint32_t cnt = 0,flag = 0;
void SysTick_Handler(void)
{
   // SysTick�жϴ�������
	if(SysTick->CTRL & SysTick_CTRL_COUNTFLAG_Msk)
	{	
		SysTick->CTRL &= ~(1<<16);
		SystemTime++;
		if(SystemTime %1000 == 0)	
		{
//			printf("1\r\n");//��׼
		}
	}
}

void SysTick_Delay_Ms(uint32_t ms)
{
	uint32_t i;	
	SysTick_Config(SystemCoreClock/1000);
	
	for(i=0;i<ms;i++)
	{
		// ����������ֵ��С��0��ʱ��CRTL�Ĵ�����λ16����1
		// ����1ʱ����ȡ��λ����0
		while( !((SysTick->CTRL)&(1<<16)) );
	}
	// �ر�SysTick��ʱ��
	SysTick->CTRL &=~ SysTick_CTRL_ENABLE_Msk;
}

