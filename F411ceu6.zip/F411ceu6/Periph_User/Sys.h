#ifndef _SYS_H
#define _SYS_H


#include "stm32f4xx.h"
#include <stdio.h>

void SysTick_Configuration(void);

void Delay_base(void);
void delay_ms(uint32_t nms);
void delay_us(uint32_t nus);

uint32_t GetCurrentTime(void);
uint32_t SysTime(void);
uint8_t SoftTimer(uint32_t BaseTime,uint32_t Timeout);

void MySystick_Config(void);
uint8_t Hse_Clock_Init(uint32_t pllm,uint32_t plln,uint32_t pllp,uint32_t pllq);
void SysTick_Delay_Ms(uint32_t ms);

#endif /*Sys.h*/
