#ifndef _TIM10_H
#define _TIM10_H


#include "stm32f4xx.h"
#include <stdio.h>


void Tim10_Config(void);

void Tim10_Delay_nus(uint16_t nus);
void Tim10_Delay_nms(uint16_t nms);





#endif /*Tim10.h*/

