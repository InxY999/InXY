#ifndef _TIM11_H
#define _TIM11_H


#include "stm32f4xx.h"
#include <stdio.h>


void Tim11_Config(void);

void Tim11_Delay_nus(uint16_t nus);
void Tim11_Delay_nms(uint16_t nms);





#endif /*Tim11.h*/

