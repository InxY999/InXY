#ifndef _UART_H
#define _UART_H


#include "stm32f4xx.h"
#include <stdio.h>

typedef struct 
{
	uint8_t recvbuff[100];
	uint8_t recvcnt;
	uint8_t recvflag;
	
}Usart1_recv_t;

extern Usart1_recv_t Usart1_recv;

void Uart_IT_Config(void);
void Uart_GPIO_Config(void);
void Uart_Config(uint32_t Baud);


void Uart1_Sendbyte(uint8_t Byte);
void Uart1_Sendstr(uint8_t *pstr);
uint8_t Uart1_Recbyte(void);

#endif /*Uart.h*/
