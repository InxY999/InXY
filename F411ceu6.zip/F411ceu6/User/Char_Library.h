#ifndef _CHAR_LIBRARY_H
#define _CHAR_LIBRARY_H


#include "stm32f4xx.h"
#include <stdio.h>
#include <stdlib.h>

extern uint8_t ASCII_8_16[];
extern uint8_t Title_Library[];




extern uint8_t title_cnt;


#endif /*Char_Library.h*/
