#ifndef _FUNC_H
#define _FUNC_H

#include "Stm32f4xx.h"

/*HarfWare Func*/
#include "Led.h"
#include "Key.h"
#include "Motor.h"
#include "OLED.h"
#include "SHT20.h"
#include "Hp6.h"
#include "Mpu6050.h"

/*Char & Pic  Library*/
#include "Char_Library.h"
#include "Pic.h"



#endif /*Func.h*/

