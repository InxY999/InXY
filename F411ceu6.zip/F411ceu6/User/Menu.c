#include "Menu.h"


void Menu_Control(void)
{
	switch(Key_Val)
	{
		case 1:break;
		case 2:break;
		case 3:break;
		case 4:break;
		case 5:break;
	}
}



