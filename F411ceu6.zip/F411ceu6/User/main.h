#ifndef _MAIN_H
#define _MAIN_H


/*System Config*/
#include <time.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/*User Config*/
#include "Led.h"
#include "Uart.h"
#include "Key.h"
#include "Motor.h"
#include "OLED.h"
#include "Sys.h"
#include "Tim10.h"
#include "Tim11.h"
#include "SHT20.h"
#include "Rtc.h"
#include "Hp6.h"
#include "Delay.h"
#include "Menu.h"

/*Char&Pic Library*/
#include "Char_Library.h"
#include "Pic.h"



#endif



