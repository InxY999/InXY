#ifndef ESP8266_AT_H
#define ESP8266_AT_H


#include "main.h"
#include "usart.h"
#include <string.h>
#include <stdio.h>


extern uint8_t usart2_txbuf[256];
extern uint8_t usart2_rxbuf[512];
extern uint8_t usart2_rxone[1];
extern uint8_t usart2_rxcounter;

void esp8266_start(void);
extern void esp8266_ATSendBuf(uint8_t* buf,uint16_t len);		//��ESP8266����ָ����������
extern void esp8266_ATSendString(char* str);								//��ESP8266ģ�鷢���ַ���
extern void esp8266_ExitUnvarnishedTrans(void);							//ESP8266�˳�͸��ģʽ
extern uint8_t esp8266_ConnectAP(void);		//ESP8266�����ȵ�
extern uint8_t esp8266_ConnectServer(void);	//ʹ��ָ��Э��(TCP/UDP)���ӵ�������
extern uint8_t esp8266_OpenTransmission(void);
extern uint8_t esp8266_check(void);
extern uint8_t esp8266_Init(void);
extern uint8_t esp8266_DisconnectServer(void);
extern uint8_t esp8266_disconnectAP(void);
extern uint8_t esp8266_restartcheck(void);
void Enter_ErrorMode(uint8_t mode);
void esp8266_sendsht20data(void);


#endif  /* ESP8266_AT_H */


