#include "HUOER.h"

//#define HUOER_Pin GPIO_PIN_7
//#define HUOER_GPIO_Port GPIOB

void HUOER_invade()
{    

 HAL_GPIO_ReadPin(HUOER_GPIO_Port,HUOER_Pin);

}
