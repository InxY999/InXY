#ifndef Keyboard_H
#define Keyboard_H



#include "main.h"



/*�������*/
#define KeyNum_0 		0
#define KeyNum_1 		1
#define KeyNum_2 		2
#define KeyNum_3 		3
#define KeyNum_None 0xFF	//�ް�������


void Keyboard_Init(void);
u8	 Keyboard_Scan(void);




#endif  /* Keyboard_H */
