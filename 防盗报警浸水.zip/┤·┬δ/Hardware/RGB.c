#include "RGB.h"


#define RBG_G_Pin GPIO_PIN_4
#define RBG_G_GPIO_Port GPIOB
#define RGB_B_Pin GPIO_PIN_5
#define RGB_B_GPIO_Port GPIOB
#define RBG_R_Pin GPIO_PIN_6
#define RBG_R_GPIO_Port GPIOB

void RGB_R_ON(void)
{
	HAL_GPIO_WritePin(RGB_R_GPIO_Port,RGB_R_Pin,GPIO_PIN_RESET);
}

void RGB_G_ON(void)
{
	HAL_GPIO_WritePin(RGB_G_GPIO_Port,RGB_G_Pin,GPIO_PIN_RESET);
}

void RGB_B_ON(void)
{
	HAL_GPIO_WritePin(RGB_B_GPIO_Port,RGB_B_Pin,GPIO_PIN_RESET);
}

void RGB_R_OFF(void)
{
	HAL_GPIO_WritePin(RGB_R_GPIO_Port,RGB_R_Pin,GPIO_PIN_SET);
}

void RGB_G_OFF(void)
{
	HAL_GPIO_WritePin(RGB_G_GPIO_Port,RGB_G_Pin,GPIO_PIN_SET);
}

void RGB_B_OFF(void)
{
	HAL_GPIO_WritePin(RGB_B_GPIO_Port,RGB_B_Pin,GPIO_PIN_SET);
}

