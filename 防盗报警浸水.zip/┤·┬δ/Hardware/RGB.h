#ifndef RGB_H
#define RGB_H



#include "main.h"





void RGB_R_ON(void);
void RGB_G_ON(void);
void RGB_B_ON(void);
void RGB_R_OFF(void);
void RGB_G_OFF(void);
void RGB_B_OFF(void);


#endif  /* RGB_H */

