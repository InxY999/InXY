#include "SHT20.h"
#include "i2c.h"
#include "delay.h"
#include "tim.h"
#include "esp8266_AT.h"

uint16_t T_Data,RH_Data;

uint8_t DataBuf[BufSize];

SHT20 Sht20;

/*��ȡ��ʪ�ȣ�������*/
void SHT20_WORK()
		{
			HAL_I2C_Mem_Read(&hi2c1,SHT20_ADDR_RD, Trig_T_Addr, I2C_MEMADD_SIZE_8BIT, DataBuf,2,0xffff);
			HAL_I2C_Mem_Read(&hi2c1,SHT20_ADDR_RD, Trig_RH_Addr, I2C_MEMADD_SIZE_8BIT, &DataBuf[2],2,0xffff);
			T_Data = ((uint16_t)DataBuf[0]<<8)+(DataBuf[1]&0xfe);
			RH_Data = ((uint16_t)DataBuf[2]<<8)+(DataBuf[3]&0xfc);
			Sht20.Tem = T_Data*175.72/65536-46.85;
			Sht20.Hum= RH_Data*125.00/65536-6.0000f;
			esp8266_sendsht20data();
			printf("TEMP=%.2f  Humidity=%.2f\r\n",Sht20.Tem,Sht20.Hum);
			delayUs(30);
		}
	


