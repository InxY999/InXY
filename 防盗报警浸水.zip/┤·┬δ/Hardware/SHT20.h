#ifndef	SHT20_H
#define SHT20_H

#include "main.h"


/*��������*/

#define SHT20_ADDR_WR 0x80
#define SHT20_ADDR_RD 0x81
#define Trig_T_Addr 0xe3
#define Trig_RH_Addr 0xe5
#define BufSize 4
#define MaxTemp 32

typedef struct
{
  float Tem;
	float Hum;
}SHT20;

extern SHT20 Sht20;
extern float TemValue;
void SHT20_WORK(void);

#endif /* SHT20_H */

